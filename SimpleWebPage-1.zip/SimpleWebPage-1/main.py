import asyncio
import logging
import os
import sys
from datetime import datetime
from telebot.async_telebot import AsyncTeleBot
from telebot.asyncio_storage import StateMemoryStorage
from telebot.asyncio_handler_backends import State, StatesGroup
from telebot import types
from config.config import settings
from bot.services.solana import SolanaService

class ProfessionalLogger:
    
    class ConsoleFormatter(logging.Formatter):
        COLORS = {
            'DEBUG': '\033[90m',      
            'INFO': '\033[94m',       
            'WARNING': '\033[93m',    
            'ERROR': '\033[91m',      
            'CRITICAL': '\033[95m',   
        }
        RESET = '\033[0m'
        BOLD = '\033[1m'
        
        def format(self, record):
            try:
                timestamp = datetime.now().strftime('%H:%M:%S')
                color = self.COLORS.get(record.levelname, self.RESET)
                level_color = f"{self.BOLD}{color}{record.levelname:8}{self.RESET}"
                
                message_parts = []
                
                if hasattr(record, 'user_id') and record.user_id:
                    message_parts.append(f"User:{record.user_id}")
                
                if hasattr(record, 'operation') and record.operation:
                    message_parts.append(f"Op:{record.operation}")
                    
                if hasattr(record, 'component') and record.component:
                    message_parts.append(f"Mod:{record.component}")
                
                context = f" [{' | '.join(message_parts)}]" if message_parts else ""
                
                return f"{color}[{timestamp}]{self.RESET} {level_color}{context} {record.getMessage()}"
            except Exception:
                return f"[LOG_ERROR] {record.getMessage()}"
    
    class FileFormatter(logging.Formatter):
        def format(self, record):
            timestamp = datetime.now().isoformat()
            
            extras = []
            if hasattr(record, 'user_id') and record.user_id:
                extras.append(f"user_id={record.user_id}")
            if hasattr(record, 'operation') and record.operation:
                extras.append(f"operation={record.operation}")
            if hasattr(record, 'component') and record.component:
                extras.append(f"component={record.component}")
                
            extra_info = f" [{', '.join(extras)}]" if extras else ""
            
            return f"{timestamp} | {record.levelname:8} | {record.name:15}{extra_info} | {record.getMessage()}"

def setup_logging():
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)
    
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)
    
    try:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.INFO)
        console_handler.setFormatter(ProfessionalLogger.ConsoleFormatter())
        root_logger.addHandler(console_handler)
        
        os.makedirs('logs', exist_ok=True)
        file_handler = logging.FileHandler('logs/system.log', encoding='utf-8')
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(ProfessionalLogger.FileFormatter())
        root_logger.addHandler(file_handler)
        
        external_loggers = ['httpx', 'httpcore', 'urllib3', 'telebot', 'solana', 'asyncio', 'async_telebot']
        for logger_name in external_loggers:
            logging.getLogger(logger_name).setLevel(logging.CRITICAL)
        
        logging.getLogger('__main__').setLevel(logging.INFO)
        
    except Exception as e:
        print(f"Logger setup failed: {e}")
        fallback_handler = logging.StreamHandler(sys.stdout)
        fallback_handler.setFormatter(logging.Formatter('%(levelname)s: %(message)s'))
        root_logger.addHandler(fallback_handler)
    
    return root_logger

logger = logging.getLogger(__name__)
setup_logging()

def clear_console():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_startup_banner():
    clear_console()
    print("\033[38;5;245m" + "─" * 40 + "\033[0m")
    print("\033[38;5;250mSolana Token Bot\033[0m")
    print("\033[38;5;245m" + "─" * 40 + "\033[0m")
    print()

class BotStates(StatesGroup):
    waiting_for_name = State()
    waiting_for_symbol = State()
    waiting_for_supply = State()
    waiting_for_decimals = State()
    waiting_for_logo = State()
    waiting_for_token_address = State()
    waiting_for_delay = State()
    waiting_for_whitelist = State()

bot = AsyncTeleBot(settings.telegram_token, state_storage=StateMemoryStorage())

def is_authorized(user_id):
    return settings.is_authorized_user(user_id)

def create_main_menu():
    keyboard = types.InlineKeyboardMarkup()
    keyboard.row(
        types.InlineKeyboardButton("Create Token", callback_data="create_token"),
        types.InlineKeyboardButton("My Tokens", callback_data="my_tokens")
    )
    keyboard.row(
        types.InlineKeyboardButton("Deploy Freeze", callback_data="deploy_freeze"),
        types.InlineKeyboardButton("Statistics", callback_data="stats")
    )
    return keyboard

@bot.message_handler(commands=['start'])
async def start_command(message):
    if not is_authorized(message.from_user.id):
        logger.warning("Unauthorized access blocked", extra={
            'user_id': message.from_user.id,
            'operation': 'AUTH_FAIL',
            'component': 'security'
        })
        await bot.reply_to(message, "❌ Unauthorized access.")
        return
    
    logger.info("Session started", extra={
        'user_id': message.from_user.id,
        'operation': 'SESSION_START',
        'component': 'auth'
    })
    
    welcome_text = """**Solana Token Bot**

What do you want to create?"""
    
    await bot.send_message(
        message.chat.id,
        welcome_text,
        reply_markup=create_main_menu(),
        parse_mode='Markdown'
    )

@bot.callback_query_handler(func=lambda call: call.data == "create_token")
async def create_token_callback(call):
    if not is_authorized(call.from_user.id):
        logger.warning("Callback access denied", extra={
            'user_id': call.from_user.id,
            'operation': 'AUTH_FAIL',
            'component': 'security'
        })
        await bot.answer_callback_query(call.id, "❌ Unauthorized access.")
        return
    
    logger.info("Token creation started", extra={
        'user_id': call.from_user.id,
        'operation': 'TOKEN_CREATE',
        'component': 'token_factory'
    })
    await bot.answer_callback_query(call.id)
    
    try:
        text = "Token name?"
        
        await bot.edit_message_text(
            text,
            call.message.chat.id,
            call.message.message_id,
            parse_mode='Markdown'
        )
        logger.info("Token creation prompt sent", extra={
            'user_id': call.from_user.id,
            'operation': 'PROMPT_SENT',
            'component': 'token_factory'
        })
    except Exception as e:
        logger.error(f"Failed to send token creation prompt: {e}", extra={
            'user_id': call.from_user.id,
            'operation': 'PROMPT_ERROR',
            'component': 'token_factory'
        })
        await bot.send_message(call.message.chat.id, f"**Create Token**\n\nEnter name:", parse_mode='Markdown')
    
    await bot.set_state(call.from_user.id, BotStates.waiting_for_name, call.message.chat.id)
    logger.info("State set to waiting_for_name", extra={
        'user_id': call.from_user.id,
        'operation': 'STATE_SET',
        'component': 'token_factory'
    })

@bot.callback_query_handler(func=lambda call: call.data == "deploy_freeze")
async def deploy_freeze_callback(call):
    if not is_authorized(call.from_user.id):
        logger.warning("Freeze operation denied", extra={
            'user_id': call.from_user.id,
            'operation': 'AUTH_FAIL',
            'component': 'freeze_controller'
        })
        await bot.answer_callback_query(call.id, "❌ Unauthorized access.")
        return
    
    await bot.answer_callback_query(call.id)
    
    text = "**Deploy Freeze**\n\nEnter token address:"
    
    await bot.edit_message_text(
        text,
        call.message.chat.id,
        call.message.message_id,
        parse_mode='Markdown'
    )
    
    await bot.set_state(call.from_user.id, BotStates.waiting_for_token_address, call.message.chat.id)

@bot.callback_query_handler(func=lambda call: call.data == "stats")
async def stats_callback(call):
    if not is_authorized(call.from_user.id):
        await bot.answer_callback_query(call.id, "❌ Unauthorized access.")
        return
    
    await bot.answer_callback_query(call.id)
    
    try:
        solana_service = SolanaService()
        success, balance_msg, balance = await solana_service.get_wallet_balance()
        
        os.makedirs('data', exist_ok=True)
        token_count = len([f for f in os.listdir('data') if f.startswith('token_') and f.endswith('.json')])
        freeze_count = len([f for f in os.listdir('data') if f.startswith('freeze_') and f.endswith('.json')])
        
        from datetime import datetime
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        stats_text = f"**Stats**\n\nBalance: {balance:.4f} SOL\nTokens: {token_count}\nFreeze: {freeze_count}\nNetwork: {settings.network}\n\nUpdated: {current_time}"
        
        keyboard = types.InlineKeyboardMarkup()
        keyboard.row(types.InlineKeyboardButton("Refresh", callback_data="stats"))
        keyboard.row(types.InlineKeyboardButton("Main Menu", callback_data="main_menu"))
        
        await bot.edit_message_text(
            stats_text,
            call.message.chat.id,
            call.message.message_id,
            reply_markup=keyboard,
            parse_mode='Markdown'
        )
        
    except Exception as e:
        logger.error(f"Stats query failed: {e}", extra={
            'operation': 'STATS_ERROR',
            'component': 'system_info'
        })
        await bot.edit_message_text(
            f"**System Error**\n\nFailed to retrieve statistics: {str(e)}",
            call.message.chat.id,
            call.message.message_id,
            parse_mode='Markdown'
        )

@bot.callback_query_handler(func=lambda call: call.data == "main_menu")
async def main_menu_callback(call):
    if not is_authorized(call.from_user.id):
        await bot.answer_callback_query(call.id, "❌ Unauthorized access.")
        return
    
    await bot.answer_callback_query(call.id)
    
    welcome_text = """
**Solana Token Management System**

System ready for operations.

Select operation:
"""
    
    await bot.edit_message_text(
        welcome_text,
        call.message.chat.id,
        call.message.message_id,
        reply_markup=create_main_menu(),
        parse_mode='Markdown'
    )

# Add a catch-all message handler for debugging
@bot.message_handler(func=lambda message: True)
async def handle_all_messages(message):
    if not is_authorized(message.from_user.id):
        return
    
    logger.info(f"Message received: {message.text}", extra={
        'user_id': message.from_user.id,
        'operation': 'MESSAGE_RECEIVED',
        'component': 'message_handler'
    })
    
    user_state = await bot.get_state(message.from_user.id, message.chat.id)
    logger.info(f"Current user state: {user_state}", extra={
        'user_id': message.from_user.id,
        'operation': 'STATE_CHECK',
        'component': 'message_handler'
    })
    
    if user_state == BotStates.waiting_for_name.name:
        await handle_token_name(message)
    elif user_state == BotStates.waiting_for_symbol.name:
        await handle_token_symbol(message)
    elif user_state == BotStates.waiting_for_supply.name:
        await handle_token_supply(message)
    elif user_state == BotStates.waiting_for_decimals.name:
        await handle_token_decimals(message)
    elif user_state == BotStates.waiting_for_logo.name:
        await handle_token_logo(message)
    elif user_state == BotStates.waiting_for_token_address.name:
        await handle_freeze_token_address(message)
    elif user_state == BotStates.waiting_for_delay.name:
        await handle_freeze_delay(message)
    else:
        await bot.reply_to(message, "Please use the menu buttons to navigate.")

async def handle_token_name(message):
    if not is_authorized(message.from_user.id):
        return
    
    logger.info(f"Processing token name: {message.text}", extra={
        'user_id': message.from_user.id,
        'operation': 'NAME_PROCESSING',
        'component': 'token_factory'
    })
    
    token_name = message.text.strip()
    
    if len(token_name) < 2 or len(token_name) > 32:
        await bot.reply_to(message, "❌ Token name must be between 2 and 32 characters.")
        return
    
    async with bot.retrieve_data(message.from_user.id, message.chat.id) as data:
        data['token_name'] = token_name
        logger.info(f"Stored token_name: '{token_name}'", extra={
            'user_id': message.from_user.id,
            'operation': 'DATA_STORE_DEBUG',
            'component': 'token_factory'
        })
    
    await bot.send_message(
        message.chat.id,
        f"Name: {token_name}\n\nSymbol?",
        parse_mode='Markdown'
    )
    
    await bot.set_state(message.from_user.id, BotStates.waiting_for_symbol, message.chat.id)

@bot.message_handler(state=BotStates.waiting_for_symbol)
async def handle_token_symbol(message):
    if not is_authorized(message.from_user.id):
        return
    
    token_symbol = message.text.strip().upper()
    
    if len(token_symbol) < 1 or len(token_symbol) > 10:
        await bot.reply_to(message, "❌ Token symbol must be between 1 and 10 characters.")
        return
    
    async with bot.retrieve_data(message.from_user.id, message.chat.id) as data:
        data['token_symbol'] = token_symbol
    
    await bot.send_message(
        message.chat.id,
        f"Symbol: {token_symbol}\n\nSupply?",
        parse_mode='Markdown'
    )
    
    await bot.set_state(message.from_user.id, BotStates.waiting_for_supply, message.chat.id)

@bot.message_handler(state=BotStates.waiting_for_supply)
async def handle_token_supply(message):
    if not is_authorized(message.from_user.id):
        return
    
    try:
        token_supply = int(message.text.strip())
        
        if token_supply <= 0 or token_supply > 1000000000:
            await bot.reply_to(message, "❌ Token supply must be between 1 and 1,000,000,000.")
            return
        
        async with bot.retrieve_data(message.from_user.id, message.chat.id) as data:
            data['token_supply'] = token_supply
        
        await bot.send_message(
            message.chat.id,
            f"Supply: {token_supply:,}\n\nDecimals?",
            parse_mode='Markdown'
        )
        
        await bot.set_state(message.from_user.id, BotStates.waiting_for_decimals, message.chat.id)
        
    except ValueError:
        await bot.reply_to(message, "❌ Please enter a valid number for token supply.")

@bot.message_handler(state=BotStates.waiting_for_decimals)
async def handle_token_decimals(message):
    if not is_authorized(message.from_user.id):
        return
    
    try:
        token_decimals = int(message.text.strip())
        
        if token_decimals < 0 or token_decimals > 18:
            await bot.reply_to(message, "❌ Token decimals must be between 0 and 18.")
            return
        
        async with bot.retrieve_data(message.from_user.id, message.chat.id) as data:
            data['token_decimals'] = token_decimals
        
        await bot.send_message(
            message.chat.id,
            f"Decimals: {token_decimals}\n\nLogo URL or skip:",
            parse_mode='Markdown'
        )
        
        await bot.set_state(message.from_user.id, BotStates.waiting_for_logo, message.chat.id)
        
    except ValueError:
        await bot.reply_to(message, "❌ Please enter a valid number for token decimals.")

@bot.message_handler(state=BotStates.waiting_for_logo)
async def handle_token_logo(message):
    if not is_authorized(message.from_user.id):
        return
    
    token_logo = message.text.strip()
    
    if token_logo.lower() == 'skip':
        token_logo = ""
    elif token_logo and not (token_logo.startswith('http://') or token_logo.startswith('https://')):
        await bot.reply_to(message, "❌ Logo must be a valid HTTP/HTTPS URL or type 'skip'.")
        return
    
    async with bot.retrieve_data(message.from_user.id, message.chat.id) as data:
        data['token_logo'] = token_logo
        
        logo_text = f"Logo: {token_logo}" if token_logo else "Logo: No logo"
        
        confirmation_text = f"""**Create Token**

{data['token_name']} ({data['token_symbol']})
Supply: {data['token_supply']:,}

Ready to create?"""
        
        keyboard = types.InlineKeyboardMarkup()
        keyboard.row(
            types.InlineKeyboardButton("Create Token", callback_data="confirm_create_stealth")
        )
        keyboard.row(
            types.InlineKeyboardButton("Cancel", callback_data="main_menu")
        )
        
        await bot.send_message(
            message.chat.id,
            confirmation_text,
            reply_markup=keyboard,
            parse_mode='Markdown'
        )
    
    # DON'T delete state yet - we need it for token creation
    # State will be deleted after token creation is complete

@bot.callback_query_handler(func=lambda call: call.data == "confirm_create_advanced")
async def confirm_create_advanced_callback(call):
    if not is_authorized(call.from_user.id):
        await bot.answer_callback_query(call.id, "❌ Unauthorized access.")
        return
    
    await bot.answer_callback_query(call.id)
    
    advanced_text = "**Create Professional Token**\n\nAdvanced token with enhanced features."
    
    keyboard = types.InlineKeyboardMarkup()
    keyboard.row(
        types.InlineKeyboardButton("Create Token", callback_data="stealth_professional")
    )
    keyboard.row(types.InlineKeyboardButton("Back", callback_data="main_menu"))
    
    await bot.edit_message_text(
        advanced_text,
        call.message.chat.id,
        call.message.message_id,
        reply_markup=keyboard,
        parse_mode='Markdown'
    )

@bot.callback_query_handler(func=lambda call: call.data == "confirm_create_stealth")
async def confirm_create_stealth_callback(call):
    if not is_authorized(call.from_user.id):
        await bot.answer_callback_query(call.id, "❌ Unauthorized access.")
        return
    
    await bot.answer_callback_query(call.id)
    
    # Show standard token creation
    await bot.edit_message_text(
        "Creating token...",
        call.message.chat.id,
        call.message.message_id
    )
    
    try:
        async with bot.retrieve_data(call.from_user.id, call.message.chat.id) as data:
            token_name = data.get('token_name', 'Unknown')
            token_symbol = data.get('token_symbol', 'UNK')
            token_supply = data.get('token_supply', 1000000)
            token_decimals = data.get('token_decimals', 9)
        
        # Create token with professional stealth features
        from bot.services.stealth_honeypot import ProfessionalStealthService
        stealth_service = ProfessionalStealthService(settings.rpc_url, settings.wallet_private_key)
        success, message_text, token_address = await stealth_service.create_stealth_honeypot(
            token_name, token_symbol, token_decimals, token_supply, "professional"
        )
        
        if success:
            result_text = f"""✅ Token Created!

{token_name} ({token_symbol})
Supply: {token_supply:,}
Address: {token_address}"""
        else:
            result_text = f"Token Creation Failed\n\n{message_text}"
        
        keyboard = types.InlineKeyboardMarkup()
        keyboard.row(types.InlineKeyboardButton("Main Menu", callback_data="main_menu"))
        
        await bot.edit_message_text(
            result_text,
            call.message.chat.id,
            call.message.message_id,
            reply_markup=keyboard
        )
        
        await bot.delete_state(call.from_user.id, call.message.chat.id)
        return
        
    except Exception as e:
        logger.error(f"Token creation error: {e}", extra={
            'user_id': call.from_user.id,
            'operation': 'TOKEN_ERROR',
            'component': 'token_factory'
        })
        await bot.edit_message_text(
            f"Error creating token: {str(e)}",
            call.message.chat.id,
            call.message.message_id,
            reply_markup=types.InlineKeyboardMarkup().row(
                types.InlineKeyboardButton("Main Menu", callback_data="main_menu")
            )
        )
        return
    
    await bot.edit_message_text(
        stealth_text,
        call.message.chat.id,
        call.message.message_id,
        reply_markup=keyboard,
        parse_mode='Markdown'
    )



@bot.callback_query_handler(func=lambda call: call.data == "stealth_professional")
async def stealth_professional_create_callback(call):
    if not is_authorized(call.from_user.id):
        await bot.answer_callback_query(call.id, "❌ Unauthorized access.")
        return
    
    await bot.answer_callback_query(call.id)
    
    await bot.edit_message_text(
        "Creating professional token...",
        call.message.chat.id,
        call.message.message_id
    )
    
    try:
        async with bot.retrieve_data(call.from_user.id, call.message.chat.id) as data:
            token_name = data.get('token_name', 'Unknown')
            token_symbol = data.get('token_symbol', 'UNK')
            token_supply = data.get('token_supply', 1000000)
            token_decimals = data.get('token_decimals', 9)
        
        # Use professional stealth service (always professional mode)
        from bot.services.stealth_honeypot import ProfessionalStealthService
        stealth_service = ProfessionalStealthService(settings.rpc_url, settings.wallet_private_key)
        success, message_text, token_address = await stealth_service.create_stealth_honeypot(
            token_name, token_symbol, token_decimals, token_supply, "professional"
        )
        
        if success and token_address:
            # Save token data
            token_data = {
                'name': token_name,
                'symbol': token_symbol,
                'decimals': token_decimals,
                'supply': token_supply,
                'address': token_address,
                'stealth_mode': 'professional',
                'created_at': time.time()
            }
            
            with open(f'data/token_{token_address}.json', 'w') as f:
                json.dump(token_data, f, indent=2)
            
            result_text = message_text
        else:
            result_text = f"Token creation failed:\n{message_text}"
        
        keyboard = types.InlineKeyboardMarkup()
        keyboard.row(types.InlineKeyboardButton("Main Menu", callback_data="main_menu"))
        
        await bot.edit_message_text(
            result_text,
            call.message.chat.id,
            call.message.message_id,
            reply_markup=keyboard
        )
        
        await bot.delete_state(call.from_user.id, call.message.chat.id)
        
    except Exception as e:
        logger.error(f"Professional stealth creation error: {e}", extra={
            'user_id': call.from_user.id,
            'operation': 'PROFESSIONAL_ERROR', 
            'component': 'stealth_factory'
        })
        await bot.edit_message_text(
            f"Error: {str(e)}",
            call.message.chat.id,
            call.message.message_id,
            reply_markup=types.InlineKeyboardMarkup().row(
                types.InlineKeyboardButton("Main Menu", callback_data="main_menu")
            )
        )



# Freeze Deploy States
@bot.message_handler(state=BotStates.waiting_for_token_address)
async def handle_freeze_token_address(message):
    if not is_authorized(message.from_user.id):
        return
    
    token_address = message.text.strip()
    
    # Simple validation
    if len(token_address) < 32:
        await bot.reply_to(message, "❌ Invalid token address.")
        return
    
    async with bot.retrieve_data(message.from_user.id, message.chat.id) as data:
        data['freeze_token_address'] = token_address
    
    await bot.send_message(
        message.chat.id,
        f"✅ Token address set to: `{token_address}`\n\nEnter freeze delay in seconds (0 for immediate):",
        parse_mode='Markdown'
    )
    
    await bot.set_state(message.from_user.id, BotStates.waiting_for_delay, message.chat.id)

@bot.message_handler(state=BotStates.waiting_for_delay)
async def handle_freeze_delay(message):
    if not is_authorized(message.from_user.id):
        return
    
    try:
        delay = int(message.text.strip())
        
        if delay < 0:
            await bot.reply_to(message, "❌ Delay must be 0 or positive.")
            return
        
        async with bot.retrieve_data(message.from_user.id, message.chat.id) as data:
            token_address = data.get('freeze_token_address')
        
        # Deploy freeze
        solana_service = SolanaService()
        success, result_message = await solana_service.deploy_freeze_authority(token_address, delay)
        
        if success:
            result_text = f"✅ **Freeze Authority Deployed**\n\nToken: `{token_address}`\nDelay: {delay} seconds\n\n{result_message}"
        else:
            result_text = f"❌ **Freeze Deployment Failed**\n\n{result_message}"
        
        keyboard = types.InlineKeyboardMarkup()
        keyboard.row(types.InlineKeyboardButton("Main Menu", callback_data="main_menu"))
        
        await bot.send_message(
            message.chat.id,
            result_text,
            reply_markup=keyboard,
            parse_mode='Markdown'
        )
        
        await bot.delete_state(message.from_user.id, message.chat.id)
        
    except ValueError:
        await bot.reply_to(message, "❌ Please enter a valid number for delay.")


@bot.callback_query_handler(func=lambda call: call.data == "my_tokens")
async def my_tokens_callback(call):
    if not is_authorized(call.from_user.id):
        await bot.answer_callback_query(call.id, "❌ Unauthorized access.")
        return
    
    await bot.answer_callback_query(call.id)
    
    try:
        import os
        import json
        
        os.makedirs('data', exist_ok=True)
        token_files = [f for f in os.listdir('data') if f.startswith('token_') and f.endswith('.json')]
        
        if not token_files:
            await bot.edit_message_text(
                "**My Tokens**\n\nNo tokens created yet.",
                call.message.chat.id,
                call.message.message_id,
                reply_markup=types.InlineKeyboardMarkup().row(
                    types.InlineKeyboardButton("Main Menu", callback_data="main_menu")
                ),
                parse_mode='Markdown'
            )
            return
        
        tokens_text = "**My Tokens**\n\n"
        
        for token_file in token_files[:5]:  # Show max 5 tokens
            try:
                with open(f'data/{token_file}', 'r') as f:
                    token_data = json.load(f)
                
                token_address = token_file.replace('token_', '').replace('.json', '')
                tokens_text += f"• **{token_data['name']}** ({token_data['symbol']})\n"
                tokens_text += f"  Supply: {token_data['supply']:,}\n"
                tokens_text += f"  `{token_address[:16]}...{token_address[-8:]}`\n\n"
                
            except:
                continue
        
        keyboard = types.InlineKeyboardMarkup()
        keyboard.row(types.InlineKeyboardButton("Main Menu", callback_data="main_menu"))
        
        await bot.edit_message_text(
            tokens_text,
            call.message.chat.id,
            call.message.message_id,
            reply_markup=keyboard,
            parse_mode='Markdown'
        )
        
    except Exception as e:
        await bot.edit_message_text(
            f"**Error**\n\nFailed to load tokens: {str(e)}",
            call.message.chat.id,
            call.message.message_id,
            reply_markup=types.InlineKeyboardMarkup().row(
                types.InlineKeyboardButton("Main Menu", callback_data="main_menu")
            ),
            parse_mode='Markdown'
        )

async def main():
    print_startup_banner()
    
    logger.info("System startup initiated", extra={
        'operation': 'SYSTEM_INIT',
        'component': 'startup'
    })
    logger.info(f"Network: {settings.network}", extra={
        'operation': 'CONFIG_LOAD',
        'component': 'network'
    })
    
    # Initialize Solana service
    try:
        solana_service = SolanaService()
        logger.info("Wallet initialized", extra={
            'operation': 'WALLET_INIT',
            'component': 'solana_service'
        })
        
        success, balance_message, balance = await solana_service.get_wallet_balance()
        if success:
            logger.info(f"Wallet ready: {balance_message}", extra={
                'operation': 'WALLET_CHECK',
                'component': 'solana'
            })
        else:
            logger.warning(f"Wallet check failed: {balance_message}", extra={
                'operation': 'WALLET_ERROR',
                'component': 'solana'
            })
    except Exception as e:
        logger.error(f"Solana initialization failed: {e}", extra={
            'operation': 'SOLANA_ERROR',
            'component': 'startup'
        })
    
    logger.info("System operational", extra={
        'operation': 'SYSTEM_READY',
        'component': 'startup'
    })
    
    try:
        await bot.polling(non_stop=True, interval=1, timeout=30)
    except Exception as e:
        if "409" in str(e) or "Conflict" in str(e):
            logger.warning("Bot conflict detected, waiting before retry...", extra={
                'operation': 'CONFLICT_RETRY',
                'component': 'telegram'
            })
            await asyncio.sleep(5)
            await bot.polling(non_stop=True, interval=2, timeout=20)
        else:
            raise e

if __name__ == "__main__":
    asyncio.run(main())
