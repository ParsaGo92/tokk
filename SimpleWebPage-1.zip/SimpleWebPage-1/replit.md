# Solana Token Creation Bot

## Overview

This is a professional Telegram bot for creating and managing SPL tokens on the Solana blockchain. The bot provides advanced token creation capabilities with stealth features, freeze authority deployment, and comprehensive token management through an intuitive Telegram interface.

## User Preferences

Preferred communication style: Simple, everyday language.
Bot messages should be user-friendly in English rather than technical.
Logging should be simplified and less verbose for end users.
Interface language: English only (no Arabic/Persian/Farsi).
Message style: Short, elegant text without emojis.
User prefers clean English interface without foreign languages.

## System Architecture

### Backend Architecture
- **Python-based Telegram Bot**: Built using the `python-telegram-bot` library with async support
- **Solana Integration**: Direct interaction with Solana blockchain via `solana-py` and `spl-token` libraries
- **Modular Service Architecture**: Separated concerns with dedicated services for Solana operations and stealth features

### Frontend Architecture
- **Telegram Interface**: Interactive keyboard-driven UI using inline keyboards
- **Conversational Flow**: State-managed user interactions for token creation workflows
- **Real-time Feedback**: Immediate response to user actions with detailed status updates

## Key Components

### 1. Bot Core (`main.py`)
- Professional logging system with color-coded console output and file logging
- Async bot initialization and handler registration
- Centralized error handling and user authentication

### 2. Configuration Management (`config/`)
- Environment-based configuration with required validation
- Support for multiple Solana networks (mainnet-beta, devnet, testnet)
- User authorization system with single authorized user model

### 3. Bot Implementation (`main.py`)
- Single-file bot implementation using telebot framework
- Integrated handlers for token creation, freeze, and management
- Clean English interface without emojis
- State-managed user interactions

### 4. Solana Service (`bot/services/solana.py`)
- SPL token creation with custom metadata
- Wallet balance checking and transaction cost calculation
- RPC client management with automatic retry logic
- Transaction signing and broadcasting

### 5. Stealth Service (`bot/services/stealth_honeypot.py`)
- Advanced stealth token creation with 7 professional techniques:
  - Dynamic PDA generation
  - Proxy Authority systems
  - Burner wallet integration
  - Oracle-based triggers
  - Commit-Reveal schemes
  - Unlinkable architecture
  - AES-256 encrypted vault storage

### 6. User Interface & Validation
- Inline keyboards integrated in main.py
- Built-in input validation for token parameters
- Clean English interface without emojis
- Simple navigation flow with error handling

## Data Flow

### Token Creation Process
1. User initiates token creation via Telegram command
2. Bot validates user authorization and presents configuration menu
3. User sets token parameters (name, symbol, supply, decimals) through interactive keyboards
4. System validates all inputs and calculates required SOL for transaction
5. Transaction is constructed, signed, and broadcast to Solana network
6. Token metadata is generated and stored locally
7. Confirmation with token address is sent to user

### Stealth Token Creation
1. Enhanced entropy generation using external oracles
2. Dynamic PDA calculation for unlinkable addresses
3. Encrypted vault storage for sensitive authority data
4. Commit-reveal scheme implementation for delayed activation
5. Decoy transaction generation for pattern obfuscation

### Data Storage
- **Local JSON Files**: Token metadata and configuration stored in `data/` directory
- **Naming Convention**: `token_{address}.json`, `metadata_{address}.json`, `stealth_{address}.json`
- **Encrypted Storage**: Sensitive data encrypted using AES-256 with derived keys

## External Dependencies

### Core Libraries
- `python-telegram-bot`: Telegram Bot API wrapper with async support
- `solana-py`: Solana blockchain interaction library
- `spl-token`: SPL token program bindings
- `base58`: Address encoding/decoding for Solana
- `httpx`: HTTP client for external API calls

### Blockchain Dependencies
- **Solana RPC**: Connection to Solana network via configurable RPC endpoint
- **SPL Token Program**: Standard token creation and management
- **System Program**: Account creation and SOL transfers

### External Services
- **Oracle Services**: External entropy sources for stealth operations
- **Metadata Storage**: Placeholder image generation via external services

## Deployment Strategy

### Environment Configuration
- Environment variables for sensitive data (private keys, tokens, user IDs)
- Support for multiple Solana networks through configuration
- Debug mode for development testing

### File System Organization
```
/
├── config/          # Configuration management  
├── bot/
│   └── services/    # Blockchain services (solana.py, stealth_honeypot.py)
├── data/           # Local data storage
└── main.py         # Complete bot implementation
```

### Security Considerations
- Single authorized user model for access control
- Private key validation and secure storage
- AES-256 encryption for sensitive vault data
- File permissions (0600) for encrypted storage
- Input validation and sanitization throughout

### Scalability Features
- Async architecture for handling multiple operations
- Modular service design for easy extension
- Configurable RPC endpoints for load balancing
- Local caching of token metadata for performance

### Error Handling
- Comprehensive logging with operation tracking
- User-friendly error messages
- Automatic retry logic for network operations
- Graceful degradation for service failures

The system is designed to be a professional-grade tool for advanced Solana token operations while maintaining user-friendly interaction patterns through Telegram's interface.