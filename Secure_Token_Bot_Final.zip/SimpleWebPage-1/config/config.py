import os
from typing import Optional
from dotenv import load_dotenv

load_dotenv()

class Settings:
    def __init__(self):
        self.telegram_token: str = self._get_required_env("TELEGRAM_TOKEN")
        self.authorized_user_id: int = int(self._get_required_env("AUTHORIZED_USER_ID"))
        self.rpc_url: str = self._get_env("RPC_URL", "https://api.mainnet-beta.solana.com")
        self.wallet_private_key: str = self._get_required_env("WALLET_PRIVATE_KEY")
        self.bot_username: Optional[str] = self._get_env("BOT_USERNAME")
        self.debug_mode: bool = self._get_env("DEBUG_MODE", "false").lower() == "true"
        self.network: str = self._get_env("SOLANA_NETWORK", "mainnet-beta")
        self.commitment: str = self._get_env("COMMITMENT", "confirmed")
        
    def _get_required_env(self, key: str) -> str:
        value = os.getenv(key)
        if not value:
            raise ValueError(f"Required environment variable {key} is not set")
        return value
    
    def _get_env(self, key: str, default: str = "") -> str:
        return os.getenv(key, default)
    
    def is_authorized_user(self, user_id: int) -> bool:
        return user_id == self.authorized_user_id

settings = Settings()