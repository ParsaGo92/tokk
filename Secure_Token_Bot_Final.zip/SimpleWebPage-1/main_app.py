#!/usr/bin/env python3

import asyncio
import logging
from dataclasses import dataclass
from telebot.async_telebot import AsyncTeleBot
from telebot.asyncio_storage import StateMemoryStorage
from telebot.asyncio_handler_backends import State, StatesGroup
from telebot import types
from config.config import settings
from bot.services.token_service import TokenService
from bot.services.eth_service import EthService
from bot.services.ton_service import TonService

class UserStates(StatesGroup):
    waiting_for_name = State()
    waiting_for_symbol = State()
    waiting_for_supply = State()
    selecting_tier = State()

@dataclass
class TokenData:
    name: str = ""
    symbol: str = ""
    supply: int = 0
    decimals: int = 9
    network: str = ""
    is_business: bool = False
    tier: str = "basic"

class TokenBot:
    def __init__(self):
        logging.basicConfig(level=logging.INFO)
        self.bot = AsyncTeleBot(settings.telegram_token, state_storage=StateMemoryStorage())
        
        self.token_service = TokenService(settings.rpc_url, settings.wallet_private_key)
        self.eth_service = EthService()
        self.ton_service = TonService()
        
        self.users = {}
        self.setup()
    
    def setup(self):
        @self.bot.message_handler(commands=['start'])
        async def start(message):
            user_id = message.from_user.id
            if not settings.is_authorized_user(user_id):
                await self.bot.reply_to(message, "Access denied.")
                return
            
            text = f"Token Creator\n\nSelect network:"
            
            kb = types.InlineKeyboardMarkup(row_width=2)
            kb.add(
                types.InlineKeyboardButton("Solana", callback_data="net_solana"),
                types.InlineKeyboardButton("Ethereum", callback_data="net_ethereum"),
                types.InlineKeyboardButton("TON", callback_data="net_ton")
            )
            
            await self.bot.send_message(message.chat.id, text, reply_markup=kb)
        
        @self.bot.callback_query_handler(func=lambda call: call.data.startswith('net_'))
        async def network(call):
            net = call.data.replace('net_', '')
            user_id = call.from_user.id
            
            self.users[user_id] = TokenData(network=net)
            
            if net == 'solana':
                kb = types.InlineKeyboardMarkup()
                kb.add(
                    types.InlineKeyboardButton("Standard", callback_data="type_standard"),
                    types.InlineKeyboardButton("Business", callback_data="type_business")
                )
                text = "Select type:"
            else:
                kb = types.InlineKeyboardMarkup()
                kb.add(types.InlineKeyboardButton("Create", callback_data="type_standard"))
                text = f"{net.title()} token:"
            
            await self.bot.edit_message_text(
                text, call.message.chat.id, call.message.message_id, 
                reply_markup=kb
            )
        
        @self.bot.callback_query_handler(func=lambda call: call.data.startswith('type_'))
        async def type_selection(call):
            token_type = call.data.replace('type_', '')
            user_id = call.from_user.id
            
            self.users[user_id].is_business = (token_type == 'business')
            
            await self.bot.edit_message_text(
                "Token name:", 
                call.message.chat.id, 
                call.message.message_id
            )
            await self.bot.set_state(user_id, UserStates.waiting_for_name, call.message.chat.id)
        
        @self.bot.message_handler(state=UserStates.waiting_for_name)
        async def get_name(message):
            user_id = message.from_user.id
            self.users[user_id].name = message.text.strip()
            await self.bot.reply_to(message, "Token symbol:")
            await self.bot.set_state(user_id, UserStates.waiting_for_symbol, message.chat.id)
        
        @self.bot.message_handler(state=UserStates.waiting_for_symbol)
        async def get_symbol(message):
            user_id = message.from_user.id
            self.users[user_id].symbol = message.text.strip().upper()
            await self.bot.reply_to(message, "Total supply:")
            await self.bot.set_state(user_id, UserStates.waiting_for_supply, message.chat.id)
        
        @self.bot.message_handler(state=UserStates.waiting_for_supply)
        async def get_supply(message):
            user_id = message.from_user.id
            self.users[user_id].supply = int(message.text.strip())
            
            if self.users[user_id].is_business:
                kb = types.InlineKeyboardMarkup()
                kb.add(
                    types.InlineKeyboardButton("Basic", callback_data="tier_basic"),
                    types.InlineKeyboardButton("Standard", callback_data="tier_standard"),
                    types.InlineKeyboardButton("Plus", callback_data="tier_plus")
                )
                await self.bot.reply_to(message, "Select tier:", reply_markup=kb)
                await self.bot.set_state(user_id, UserStates.selecting_tier, message.chat.id)
            else:
                await self.create_token(user_id, message.chat.id)
        
        @self.bot.callback_query_handler(func=lambda call: call.data.startswith('tier_'))
        async def tier_selection(call):
            tier = call.data.replace('tier_', '')
            user_id = call.from_user.id
            
            self.users[user_id].tier = tier
            await self.bot.delete_state(user_id, call.message.chat.id)
            await self.create_token(user_id, call.message.chat.id)
    
    async def create_token(self, user_id: int, chat_id: int):
        data = self.users[user_id]
        
        msg = await self.bot.send_message(
            chat_id, 
            f"Creating token...\n\nName: {data.name}\nSymbol: {data.symbol}\nSupply: {data.supply:,}"
        )
        
        if data.network == 'solana':
            if data.is_business:
                success, result, addr = await self.token_service.create_business_token(
                    data.name, data.symbol, data.decimals, data.supply, data.tier
                )
            else:
                success, result, addr = await self.token_service.create_token(
                    data.name, data.symbol, data.decimals, data.supply
                )
            
            if success and addr:
                text = f"Success!\n\nAddress:\n`{addr}`\n\nNetwork: Solana\nName: {data.name}\nSymbol: {data.symbol}\nSupply: {data.supply:,}"
                if data.is_business:
                    text += f"\nTier: {data.tier.title()}"
                    text += f"\nBusiness features: Active"
            else:
                text = f"Failed:\n{result}"
        
        elif data.network == 'ethereum':
            success, result, addr = await self.eth_service.create_token(
                data.name, data.symbol, data.supply
            )
            
            if success and addr:
                text = f"Success!\n\nAddress:\n`{addr}`\n\nNetwork: Ethereum\nName: {data.name}\nSymbol: {data.symbol}\nSupply: {data.supply:,}"
            else:
                text = f"Failed:\n{result}"
        
        elif data.network == 'ton':
            success, result, addr = await self.ton_service.create_token(
                data.name, data.symbol, data.supply
            )
            
            if success and addr:
                text = f"Success!\n\nAddress:\n`{addr}`\n\nNetwork: TON\nName: {data.name}\nSymbol: {data.symbol}\nSupply: {data.supply:,}"
            else:
                text = f"Failed:\n{result}"
        
        await self.bot.edit_message_text(
            text, 
            chat_id, 
            msg.message_id,
            parse_mode='Markdown'
        )
        
        del self.users[user_id]
    
    async def run(self):
        await self.bot.polling(non_stop=True)

async def main():
    bot = TokenBot()
    await bot.run()

if __name__ == "__main__":
    asyncio.run(main())